## Intro

This is the source code for our Youtube Series: [Laravel API Server from scratch](https://www.youtube.com/playlist?list=PLSfH3ojgWsQosqpQUc28yP9jJZXrEylJY) (ep5 onwards)

## Support us

[Subscribe](https://www.youtube.com/c/Acadeaio?sub_confirmation=1 ) to our Youtube Channel

Become a Pro Acadea member today for more content! [https://www.acadea.io/learn](https://www.acadea.io/learn) 

Join my newsletter here to get the BEST updates: https://sendfox.com/acadea

Paypal Donation: [https://www.paypal.com/donate/?hosted_button_id=HPD9HHN3HBPDC](https://www.paypal.com/donate/?hosted_button_id=HPD9HHN3HBPDC)

Buy me a coffee: [https://www.buymeacoffee.com/acadea](https://www.buymeacoffee.com/acadea)

Follow me on Medium: [https://sam-ngu.medium.com/](https://sam-ngu.medium.com/)

## How to use this repo?
There is a branch for each lesson. Simply switch to the respective branch to view the relevant source code of the lesson! 

## Contributing

Contributions are welcome and will be fully credited.

Please submit a pull request if you noticed an error or wanted to improve the source code.


## Credits

- [sam-ngu](https://github.com/sam-ngu)
- [All Contributors](../../contributors)