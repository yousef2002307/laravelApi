@component("mail::message")

# OIIIII

## Click the link [here]({{$url}})

@endcomponent